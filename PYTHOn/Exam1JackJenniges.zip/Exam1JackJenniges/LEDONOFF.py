import serial
import time


class LEDONOFF:
    def __init__(self, port="/dev/ttyACM0"):
        self.port = port
        self.ser = None

    def connect(self):
        if self.ser and self.ser.is_open:
            return
        self.ser = serial.Serial(port=self.port, baudrate=19200, timeout=10)
        time.sleep(2.0)
        self.ser.reset_input_buffer()

    def disconnect(self):
        if self.ser and self.ser.is_open:
            self.ser.close()

    def ONOFF(self, command):
        self.ser.reset_input_buffer()
        message_bytes = (command + "\n").encode()
        print(message_bytes)
        self.ser.write(message_bytes)
        response_bytes = self.ser.readline()
        print(response_bytes)
        response = response_bytes.decode().strip()
        return response

    def flash(self, count, delaytime):
        self.ser.reset_input_buffer()
        command = f"Flash {count} {delaytime}"
        message_bytes = (command + "\n").encode()
        print(message_bytes)
        self.ser.write(message_bytes)
        response_bytes = self.ser.readline()
        print(response_bytes)
        response = response_bytes.decode().strip()
        return response